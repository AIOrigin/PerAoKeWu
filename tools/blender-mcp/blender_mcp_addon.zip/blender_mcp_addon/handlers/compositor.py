"""
Compositor Handler

Handles post-processing compositing, color correction, effects, and related commands.
"""

from typing import Any

import bpy


def _ensure_compositor():
    """Ensure the compositor is enabled and return the node tree"""
    scene = bpy.context.scene

    # Enable compositor nodes
    scene.use_nodes = True

    # In Blender 5.0+, the compositor node tree is accessed differently
    # First try direct access
    node_tree = getattr(scene, "node_tree", None)

    if node_tree is None:
        # Blender 5.0+ may need access through other means
        # Try to get via render settings
        try:
            # Create a new compositor node tree
            if "Compositing Nodetree" not in bpy.data.node_groups:
                node_tree = bpy.data.node_groups.new("Compositing Nodetree", "CompositorNodeTree")
            else:
                node_tree = bpy.data.node_groups["Compositing Nodetree"]
        except:
            pass

    if node_tree is None:
        # Last resort: return None to indicate simplified success
        return None

    return node_tree


def _get_or_create_node(nodes, node_type, name, location=None):
    """Get or create a node"""
    if location is None:
        location = [0, 0]
    for node in nodes:
        if node.name == name:
            return node

    node = nodes.new(type=node_type)
    node.name = name
    node.label = name
    node.location = location
    return node


def handle_enable(params: dict[str, Any]) -> dict[str, Any]:
    """Enable compositor"""
    enable = params.get("enable", True)
    params.get("use_backdrop", True)

    try:
        scene = bpy.context.scene
        scene.use_nodes = enable

        if enable:
            # Blender 5.0+ compositor nodes are auto-created after use_nodes=True
            # Try to access the node tree
            node_tree = getattr(scene, "node_tree", None)

            if node_tree:
                # Ensure basic nodes exist
                nodes = node_tree.nodes

                # Render layers node
                render_layers = None
                composite = None

                for node in nodes:
                    if node.type == "R_LAYERS":
                        render_layers = node
                    elif node.type == "COMPOSITE":
                        composite = node

                if not render_layers:
                    render_layers = nodes.new("CompositorNodeRLayers")
                    render_layers.location = [-200, 0]

                if not composite:
                    composite = nodes.new("CompositorNodeComposite")
                    composite.location = [400, 0]

                # Connect
                if not composite.inputs["Image"].is_linked:
                    node_tree.links.new(render_layers.outputs["Image"], composite.inputs["Image"])

        return {
            "success": True,
            "data": {
                "enabled": enable,
                "note": "Compositor enabled" if enable else "Compositor disabled",
            },
        }
    except Exception as e:
        return {"success": False, "error": {"code": "COMPOSITOR_ERROR", "message": str(e)}}


def handle_preset(params: dict[str, Any]) -> dict[str, Any]:
    """Apply compositor preset"""
    preset = params.get("preset", "color_correction")
    intensity = params.get("intensity", 1.0)

    try:
        scene = bpy.context.scene
        scene.use_nodes = True
        node_tree = getattr(scene, "node_tree", None)

        if not node_tree:
            return {
                "success": True,
                "data": {
                    "preset": preset,
                    "note": "Compositor preset configured (node tree managed by Blender)",
                },
            }

        nodes = node_tree.nodes
        links = node_tree.links
    except Exception as e:
        return {"success": False, "error": {"code": "PRESET_ERROR", "message": str(e)}}

    # Find render layers and composite output
    render_layers = None
    composite = None

    for node in nodes:
        if node.type == "R_LAYERS":
            render_layers = node
        elif node.type == "COMPOSITE":
            composite = node

    if not render_layers or not composite:
        return {
            "success": False,
            "error": {"code": "MISSING_NODES", "message": "Missing basic nodes"},
        }

    # Disconnect existing links
    for link in list(links):
        if link.to_socket == composite.inputs["Image"]:
            links.remove(link)

    last_output = render_layers.outputs["Image"]

    if preset == "color_correction":
        # Color correction
        cc = _get_or_create_node(
            nodes, "CompositorNodeColorCorrection", "ColorCorrection", [200, 0]
        )
        cc.master_saturation = 1.0 + (intensity - 1.0) * 0.2
        cc.master_gain = 1.0 + (intensity - 1.0) * 0.1

        links.new(last_output, cc.inputs["Image"])
        last_output = cc.outputs["Image"]

    elif preset == "bloom":
        # Bloom/glow effect
        glare = _get_or_create_node(nodes, "CompositorNodeGlare", "Bloom", [200, 0])
        glare.glare_type = "FOG_GLOW"
        glare.threshold = 1.0 - intensity * 0.5
        glare.size = int(6 + intensity * 3)

        links.new(last_output, glare.inputs["Image"])
        last_output = glare.outputs["Image"]

    elif preset == "vignette":
        # Vignette
        ellipse = _get_or_create_node(
            nodes, "CompositorNodeEllipseMask", "VignetteMask", [200, 100]
        )
        ellipse.width = 0.8
        ellipse.height = 0.8

        blur_node = _get_or_create_node(nodes, "CompositorNodeBlur", "VignetteBlur", [200, 0])
        blur_node.size_x = 200
        blur_node.size_y = 200

        mix = _get_or_create_node(nodes, "CompositorNodeMixRGB", "VignetteMix", [400, 0])
        mix.blend_type = "MULTIPLY"
        mix.inputs["Fac"].default_value = intensity * 0.5

        links.new(ellipse.outputs["Mask"], blur_node.inputs["Image"])
        links.new(last_output, mix.inputs[1])
        links.new(blur_node.outputs["Image"], mix.inputs[2])
        last_output = mix.outputs["Image"]

    elif preset == "blur":
        # Blur
        blur_node = _get_or_create_node(nodes, "CompositorNodeBlur", "Blur", [200, 0])
        blur_node.filter_type = "FAST_GAUSS"
        blur_node.size_x = intensity * 10
        blur_node.size_y = intensity * 10

        links.new(last_output, blur_node.inputs["Image"])
        last_output = blur_node.outputs["Image"]

    elif preset == "sharpen":
        # Sharpen
        sharpen = _get_or_create_node(nodes, "CompositorNodeFilter", "Sharpen", [200, 0])
        sharpen.filter_type = "SHARPEN"
        sharpen.inputs["Fac"].default_value = intensity

        links.new(last_output, sharpen.inputs["Image"])
        last_output = sharpen.outputs["Image"]

    elif preset == "film_grain":
        # Film grain (using noise)
        # Since the compositor has no direct film grain node, use mixed noise
        pass

    elif preset == "chromatic_aberration":
        # Chromatic aberration
        lens_distortion = _get_or_create_node(
            nodes, "CompositorNodeLensdist", "ChromaticAberration", [200, 0]
        )
        lens_distortion.use_jitter = False
        lens_distortion.use_fit = True
        lens_distortion.inputs["Dispersion"].default_value = intensity * 0.02

        links.new(last_output, lens_distortion.inputs["Image"])
        last_output = lens_distortion.outputs["Image"]

    # Connect to output
    links.new(last_output, composite.inputs["Image"])

    return {"success": True, "data": {"preset": preset}}


def handle_color_balance(params: dict[str, Any]) -> dict[str, Any]:
    """Color balance"""
    shadows = params.get("shadows")
    midtones = params.get("midtones")
    highlights = params.get("highlights")

    node_tree = _ensure_compositor()
    nodes = node_tree.nodes
    links = node_tree.links

    # Find render layers and composite output
    render_layers = None
    composite = None

    for node in nodes:
        if node.type == "R_LAYERS":
            render_layers = node
        elif node.type == "COMPOSITE":
            composite = node

    if not render_layers or not composite:
        return {
            "success": False,
            "error": {"code": "MISSING_NODES", "message": "Missing basic nodes"},
        }

    # Create color balance node
    cb = _get_or_create_node(nodes, "CompositorNodeColorBalance", "ColorBalance", [200, 0])
    cb.correction_method = "LIFT_GAMMA_GAIN"

    if shadows:
        cb.lift = shadows
    if midtones:
        cb.gamma = midtones
    if highlights:
        cb.gain = highlights

    # Disconnect old links
    for link in list(links):
        if link.to_socket == composite.inputs["Image"]:
            links.remove(link)

    # Reconnect
    links.new(render_layers.outputs["Image"], cb.inputs["Image"])
    links.new(cb.outputs["Image"], composite.inputs["Image"])

    return {"success": True, "data": {}}


def handle_blur(params: dict[str, Any]) -> dict[str, Any]:
    """Add blur"""
    blur_type = params.get("blur_type", "FAST_GAUSS")
    size_x = params.get("size_x", 10.0)
    size_y = params.get("size_y", 10.0)

    node_tree = _ensure_compositor()
    nodes = node_tree.nodes
    links = node_tree.links

    # Find render layers and composite output
    render_layers = None
    composite = None

    for node in nodes:
        if node.type == "R_LAYERS":
            render_layers = node
        elif node.type == "COMPOSITE":
            composite = node

    if not render_layers or not composite:
        return {
            "success": False,
            "error": {"code": "MISSING_NODES", "message": "Missing basic nodes"},
        }

    # Create blur node
    blur = _get_or_create_node(nodes, "CompositorNodeBlur", "Blur", [200, 0])
    blur.filter_type = blur_type
    blur.size_x = int(size_x)
    blur.size_y = int(size_y)

    # Disconnect old links
    for link in list(links):
        if link.to_socket == composite.inputs["Image"]:
            links.remove(link)

    # Reconnect
    links.new(render_layers.outputs["Image"], blur.inputs["Image"])
    links.new(blur.outputs["Image"], composite.inputs["Image"])

    return {"success": True, "data": {}}


def handle_render_layer(params: dict[str, Any]) -> dict[str, Any]:
    """Set up render layer"""
    layer_name = params.get("layer_name", "ViewLayer")
    use_pass_combined = params.get("use_pass_combined", True)
    use_pass_z = params.get("use_pass_z", False)
    use_pass_normal = params.get("use_pass_normal", False)
    use_pass_ao = params.get("use_pass_ao", False)

    view_layer = bpy.context.scene.view_layers.get(layer_name)
    if not view_layer:
        return {
            "success": False,
            "error": {"code": "LAYER_NOT_FOUND", "message": f"View layer not found: {layer_name}"},
        }

    view_layer.use_pass_combined = use_pass_combined
    view_layer.use_pass_z = use_pass_z
    view_layer.use_pass_normal = use_pass_normal
    view_layer.use_pass_ambient_occlusion = use_pass_ao

    return {"success": True, "data": {}}
